from django.db import models
from django.utils import timezone

from orders.models import Order


class Payment(models.Model):
    stripe_checkout_id = models.CharField()
    order: models.ForeignKey = models.ForeignKey(
        Order,
        related_name="payments",
        on_delete=models.CASCADE,
    )
    amount = models.DecimalField(decimal_places=2, max_digits=8)
    payment_method = models.CharField(null=True, blank=True)
    is_paid = models.BooleanField(default=False)
    created_at = models.DateTimeField(default=timezone.now)

    def get_status_for_display(self) -> str:
        if self.is_paid:
            return "Paid"
        else:
            return "Unpaid"
